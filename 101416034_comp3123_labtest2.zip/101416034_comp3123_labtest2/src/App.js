import React, { useState, useEffect } from "react";
import axios from "axios";
import "./App.css";

const App = () => {
  const [city, setCity] = useState("Toronto"); // Default city
  const [weatherData, setWeatherData] = useState(null); // Weather data from API
  const [error, setError] = useState(null); // Error handling
  const API_KEY = "ee26972d580bc7df0ec1e37aa3216462"; // Replace with your OpenWeatherMap API Key

  // Fetch weather data from the API
  const fetchWeatherData = async (cityName) => {
    try {
      setError(null); // Reset error
      const response = await axios.get(
        `http://api.openweathermap.org/data/2.5/weather?q=${cityName}&appid=${API_KEY}&units=metric`
      );
      setWeatherData(response.data);
    } catch (err) {
      setError("City not found. Please try again.");
    }
  };

  // Fetch default city weather on first render
  useEffect(() => {
    fetchWeatherData(city);
  }, []);

  // Handle city search
  const handleSearch = (e) => {
    e.preventDefault();
    if (city.trim() === "") {
      setError("City name cannot be empty.");
      return;
    }
    fetchWeatherData(city);
  };

  return (
    <div className="App">
      <header className="header">
        <h1>Weather App</h1>
      </header>

      <form onSubmit={handleSearch} className="search-form">
        <input
          type="text"
          placeholder="Enter city"
          value={city}
          onChange={(e) => setCity(e.target.value)}
        />
        <button type="submit">Search</button>
      </form>

      {error && <p className="error">{error}</p>}

      {weatherData && (
        <div className="weather-container">
          <h2>{weatherData.name}</h2>
          <p>{weatherData.weather[0].description}</p>
          <p>Temperature: {Math.round(weatherData.main.temp)}°C</p>
          <p>Humidity: {weatherData.main.humidity}%</p>
          <p>Wind Speed: {weatherData.wind.speed} m/s</p>
          <img
            src={`http://openweathermap.org/img/wn/${weatherData.weather[0].icon}@2x.png`}
            alt="Weather Icon"
          />
        </div>
      )}
    </div>
  );
};

export default App;
